import Footer from '../components/Footer';
import Header from '../components/Header';
import Inquerito from '../components/inqueritoHome/Inquerito'


function Inq() {

    return (
      <>
        <Header/>
        <main>
          <Inquerito/>
        </main>
        <Footer/>
      </>
    );

  }
  
  export default Inq;
