import "./Header.css"

function Header() {

    return (
        <header>
            <br></br>
                <h1>Festival de Música Vilar de Mouros 2025</h1>
                <br></br>
                <nav>
                    <a href="home.html" class="navlink">Pagina Inicial</a>
                    <a href="form.html" class="navlink">Formulário de Voluntariado</a>
                    <br></br>
                </nav>
        </header>
    );
}
export default Header;